# 📧 Email Notification Subsystem (Admin Panel)

## 📋 Огляд
Цей модуль є адміністративною панеллю для керування транзакційними листами та маркетинговими розсилками SaaS продукту "AI Advisory Board". Він забезпечує інтерфейс для редагування шаблонів листів, перегляду статистики, логів відправки та керування підписниками.

Модуль розроблений як Single Page Application (SPA) на базі React 19 та Tailwind CSS, готовий до інтеграції в основний моноліт або як окремий мікро-фронтенд.

---

## 🛠 Технічний Стек

*   **Core:** React 19 (Functional Components, Hooks)
*   **Router:** React Router DOM v7
*   **Styling:** Tailwind CSS (включаючи Dark Mode `class` strategy)
*   **Icons:** Lucide React
*   **Charts:** Recharts (BarChart, PieChart)
*   **Build/Runtime:** Browser-native ES Modules (для MVP), сумісний з Vite/Webpack.

---

## 📂 Структура Файлів та Компонентів

Для інтеграції в основний проєкт рекомендується наступна структура папок (`src/features/email-admin/`):

```text
src/features/email-admin/
├── components/
│   ├── ui/                 # Базові UI компоненти (Card, Badge, Modal)
│   ├── layout/             # Sidebar, Header, Layout wrapper
│   ├── editor/             # Rich Text Toolbar, Preview Renderer
│   └── charts/             # Обгортки над Recharts
├── contexts/
│   ├── ThemeContext.tsx    # Керування темою (Light/Dark)
│   └── ToastContext.tsx    # Система сповіщень
├── pages/
│   ├── Dashboard.tsx       # Головна статистика
│   ├── EmailTypesList.tsx  # Список типів листів
│   ├── EmailDetail.tsx     # Редактор шаблону (Write/Preview, Test Send)
│   ├── Logs.tsx            # Логи відправок з пагінацією
│   ├── Subscribers.tsx     # Таблиця підписників
│   └── Settings.tsx        # Глобальні налаштування
├── services/
│   ├── api.ts              # Інтерфейс для реального API (замінить mockService)
│   └── mockService.ts      # Генерація тестових даних (для розробки)
├── types.ts                # TypeScript інтерфейси та Enums
└── constants.ts            # Початкові шаблони (14 листів) та конфігурація
```

---

## 🚀 Функціональність

### 1. Dashboard (`/`)
*   **KPI Cards:** Загальна кількість відправлених, % доставки, нові підписники, черга.
*   **Графіки:**
    *   Bar Chart: Статистика за останні 24 години (Sent/Opened/Clicked/Failed).
    *   Pie Chart: Розподіл статусів доставки.

### 2. Керування Типами Листів (`/email-types`)
*   Список з 14 попередньо налаштованих системних листів (Реєстрація, Онбординг, Юридичні, Маркетинг).
*   Фільтрація за категоріями.
*   Швидке увімкнення/вимкнення некритичних листів.
*   Відображення критичності (Critical) та отримувачів.

### 3. Редактор Шаблонів (`/email-types/:id`)
*   **Багатомовність:** Підтримка вкладок для UA/EN (масштабується).
*   **Smart Editor:**
    *   Підтримка Markdown (Bold, Italic, Link).
    *   Toolbar для форматування.
    *   Вставка змінних (`{{user_name}}`) через клік по сайдбару.
    *   Пошук по доступних змінних.
*   **Preview Mode:** Попередній перегляд відрендереного листа (Markdown -> HTML).
*   **Test Send:** Модальне вікно для відправки тестового листа на вказаний email.
*   **Unsaved Changes Protection:** Попередження при спробі вийти без збереження (Dirty State).

### 4. Логи (`/logs`)
*   Табличне відображення історії відправок.
*   Пошук за отримувачем або ID типу листа.
*   Клієнтська пагінація.
*   Статуси: Sent, Failed (з текстом помилки), Queued.

### 5. Підписники (`/subscribers`)
*   Список підписників на Newsletter.
*   Статуси (Confirmed, Pending, Unsubscribed).
*   Заглушки для експорту CSV та ручного додавання.

### 6. Налаштування (`/settings`)
*   Конфігурація відправника (Name, Email, Reply-To).
*   Rate Limiting (ліміти листів на день).
*   Quiet Hours (часові вікна для розсилок).

### 7. Глобальні Фічі
*   **Dark Mode:** Повна підтримка темної теми з корекцією контрасту.
*   **Toast Notifications:** Неблокуючі сповіщення про успіх/помилки.
*   **Responsive:** Адаптація під мобільні пристрої (Hamburger menu).

---

## 🔌 Схема Імплементації (Integration Plan)

### Крок 1: Перенесення Типів (`types.ts`)
Скопіюйте файл `types.ts`. Переконайтеся, що Enums (`Language`, `EmailCategory`) синхронізовані з вашим бекендом (або створіть мапери).

### Крок 2: Налаштування Роутингу
В `App.tsx` зараз використовується `HashRouter` для демо. В основному проєкті замініть його на вкладені роути вашого головного роутера:

```tsx
// Example main App router
<Route path="admin/emails" element={<EmailAdminLayout />}>
  <Route index element={<Dashboard />} />
  <Route path="types" element={<EmailTypes />} />
  <Route path="types/:id" element={<EmailDetail />} />
  {/* ... other routes */}
</Route>
```

### Крок 3: Підключення API (Backend Integration)
Поточний додаток працює на `mockService.ts` та `constants.ts`. Необхідно створити шар API сервісів:

1.  **GET /api/email-types**: Отримання списку типів та їх налаштувань.
2.  **PUT /api/email-types/:id**: Збереження шаблонів (тіло запиту має містити об'єкт `templates` для різних мов).
3.  **POST /api/email/test**: Ендпоінт для "Send Test Email".
4.  **GET /api/logs**: Отримання логів (з підтримкою server-side pagination).

### Крок 4: Стилізація
Переконайтеся, що `tailwind.config.js` основного проєкту включає шляхи до нових компонентів. Додаток використовує кастомні кольори `slate-850` та `slate-950` для темної теми — додайте їх у конфіг.

```javascript
// tailwind.config.js
theme: {
  extend: {
    colors: {
      slate: {
        850: '#1e293b',
        950: '#0f172a',
      }
    }
  }
}
```

---

## ⚠️ Edge Cases та Важливі Нюанси

1.  **Безпека (XSS):** В компоненті `EmailDetail` використовується спрощений парсер Markdown для прев'ю. При використанні реального HTML з бекенду, обов'язково використовуйте санітайзер (наприклад, `dompurify`).
2.  **Валідація змінних:** На бекенді потрібно валідувати, що адмін не видалив обов'язкові змінні (наприклад, лінк підтвердження) з критичних листів.
3.  **Concurrency:** Якщо два адміна редагують один шаблон, останній запис перезапише попередній. Рекомендується додати механізм блокування або перевірку версій (Optimistic Locking).

---

## 📦 Initial Data (Seed)
Файл `constants.ts` містить повний текст 14 листів для MVP (UA/EN). Використовуйте цей файл для створення початкової міграції бази даних (Database Seed).
